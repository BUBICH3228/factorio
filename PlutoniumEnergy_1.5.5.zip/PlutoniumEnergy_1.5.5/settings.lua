data:extend({
    {
        name = 'PE-disable-MOX-reactor',
        type = 'bool-setting',
        default_value = false,
        setting_type = 'startup'
    },
    {
        name = 'enable-plutonium-ammo',
        type = 'bool-setting',
        default_value = true,
        setting_type = 'startup'
    }
})
