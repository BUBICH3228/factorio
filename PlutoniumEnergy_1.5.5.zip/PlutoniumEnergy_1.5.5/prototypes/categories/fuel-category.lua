data:extend({
    {
        type = "fuel-category",
        name = "MOX"
    },
    {
        type = 'fuel-category',
        name = 'nuclear-breeder'
    }
})
