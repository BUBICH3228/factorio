data:extend({
  {
    type = "bool-setting",
    name = "bobmods-library-technology-cleanup",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "bobmods-library-recipe-cleanup",
    setting_type = "startup",
    default_value = true,
  },
})
