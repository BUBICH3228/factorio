data:extend({{
	type = "fuel-category",
	name = "SteamTrains-steam"
}})