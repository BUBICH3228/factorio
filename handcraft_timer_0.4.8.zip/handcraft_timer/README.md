# Hand Craft Timer

A simple Factorio mod that displays the amount of time left to complete the
crafting queue - made to fulfill [a mod request](https://www.reddit.com/r/factorio/comments/p0qlf0/mod_request_total_time_left_for_handcrafting_queue/).