local recipe_prerequisites = {
	["miniloader"] = { "ir2-electronics-1", "ir2-iron-motor" },
	["fast-miniloader"] = { "ir2-electronics-2", "electric-engine" },
	["express-miniloader"] = { "ir2-electronics-3" },
}

if mods["miniloader"] and mods["IndustrialRevolution"] then
	-- Update technology prerequisites.
	for technology_name, prerequisites in pairs(recipe_prerequisites) do
		local technology = data.raw.technology[technology_name]

		if technology ~= nil then
			local prerequisites_exist = true
			local found_ingredients = false
			local ingredient_map = {}
			local count = 0
			local time = 0

			for _, prereq_technology_name in ipairs(prerequisites) do
				local prereq_technology = data.raw.technology[prereq_technology_name]

				if prereq_technology == nil then
					log("Missing prereq tech " .. prereq_technology_name .. " for " .. technology_name)
					prerequisites_exist = false
				else
					-- Use the time from the pre-req tech, if higher than what we've already found.
					if prereq_technology.unit.time > time then
						time = prereq_technology.unit.time
					end

					-- Use the count from the pre-req tech, if higher than what we've already found.
					if prereq_technology.unit.count ~= nil and prereq_technology.unit.count > count then
						count = prereq_technology.unit.count
					end

					-- Collect the ingredients in the pre-req, so that this technology uses them as well.
					for _, ingredient in ipairs(prereq_technology.unit.ingredients) do
				        local ingredient_type = ingredient.type or "item"
				        local ingredient_name = ingredient.name or ingredient[1]
				        local ingredient_amount = ingredient.amount or ingredient[2] or 1
				        local ingredient_key = ingredient_type .. ":" .. ingredient_name

						if ingredient_map[ingredient_key] == nil or ingredient_amount > ingredient_map[ingredient_key].amount then
							found_ingredients = true
							ingredient_map[ingredient_key] = {
								type = ingredient_type,
								name = ingredient_name,
								amount = ingredient_amount,
							}
						end
					end
				end
			end

			if prerequisites_exist then
				technology.prerequisites = prerequisites
			end

			if count == 0 then
				log("Did not find 'count' in prereqs of " .. technology_name)
			else
				technology.unit.count = count
			end

			if time == 0 then
				log("Did not find 'time' in prereqs of " .. technology_name)
			else
				technology.unit.time = time
			end

			if not found_ingredients then
				log("Did not find 'ingredients' in prereqs of " .. technology_name)
			else
				technology.unit.ingredients = {}
				for _, ingredient in pairs(ingredient_map) do
					table.insert(technology.unit.ingredients, ingredient)
				end
			end
		end
	end
end
