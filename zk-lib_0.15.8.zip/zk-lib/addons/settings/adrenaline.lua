data:extend({
	{
		type = "int-setting",
		name = "adrenaline_bonus_modifier",
		setting_type = "runtime-global",
		default_value = 2,
		minimum_value = 1,
		maximum_value = 10,
	}
})
