data:extend({
	{
		type = "int-setting",
		name = "radius-scan-rocket-with-radars",
		setting_type = "runtime-global",
		order = "a",
		default_value = 18,
		minimum_value = 1,
		maximum_value = 100
	}
})
