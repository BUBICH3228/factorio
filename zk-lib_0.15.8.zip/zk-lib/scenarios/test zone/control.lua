mod_name = "__base__"
event_listener = require("__zk-lib__/event-listener/branch-1/stable-version")
local libs = require('libs')

event_listener.add_libraries(libs)
