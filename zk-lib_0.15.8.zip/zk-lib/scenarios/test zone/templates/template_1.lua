local module = {}
module.events = {}

local function on_init()

end

local function on_load()

end

module.on_init = on_init
module.on_load = on_load

-- For attaching events
-- module.events[defines.events.event_name] = your_function

return module
