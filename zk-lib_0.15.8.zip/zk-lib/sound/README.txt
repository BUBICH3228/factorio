Flashlight Click by dersuperanton freesound.org
Interface3 by Eternitys freesound.org
tone beep lower slower by pan14 freesound.org
guiclick by farpro freesound.org
infobleep by Divinux freesound.org