do
  local _with_0 = require("__zk-lib__/lualib/moonscript/base")
  _with_0.insert_loader()
  return _with_0
end
