#! /usr/bin/env bash

cd src
luajit ../scripts/pack.lua > ../lulpeg.lua