return {
    sep = '/',
    __binary_prefix = ""
 }
