lazyAPI.get_stage() -- in order to get this stage internally
ZKSettings.set_default_colors()
