data:extend{
	{
	  type = "font",
	  name = "SymbolsNerdFont16",
	  from = "SymbolsNerdFont",
	  size = 16,
	}, {
	  type = "font",
	  name = "SymbolsNerdFontMono16",
	  from = "SymbolsNerdFontMono",
	  size = 16,
	}, {
	  type = "font",
	  name = "SymbolsNerdFont32",
	  from = "SymbolsNerdFont",
	  size = 32,
	}, {
	  type = "font",
	  name = "SymbolsNerdFontMono32",
	  from = "SymbolsNerdFontMono",
	  size = 32,
	}
}
