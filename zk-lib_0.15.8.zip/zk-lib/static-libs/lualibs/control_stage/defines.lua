---@class ZK_defines
local ZK_defines = {}


---@type string[]
ZK_defines.turret_types = {
	"artillery-turret", "electric-turret", "fluid-turret",
	"ammo-turret", "turret"
}


return ZK_defines
