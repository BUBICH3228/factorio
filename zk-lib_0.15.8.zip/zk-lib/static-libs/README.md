Example:

```sh
git submodule add https://github.com/ZwerOxotnik/zk-factorio-static-lib zk-static-lib
```