# Event listener

## Overview

The script combines events of other scripts and adding new manipulation with events (such like canceling an event, packaging). Designed for mod developers. There is an example in the mod. Don't forget about dependencies to use the script properly.
