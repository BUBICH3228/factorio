if game.tick > 0
	and #global.chunklist > 0
	and global.chunklist[1].surface == nil
then
	global.chunklist = {}
	for index,surface in pairs(game.surfaces) do
		for coords in surface.get_chunks() do
			if surface.is_chunk_generated(coords) then
				local chunk = chunk_to_tiles(coords)
				chunk.surface = surface.index
				table.insert(global.chunklist, chunk)
			end
		end
	end
end