if global.groups == nil then
	global.groups = {}
end