data:extend({
	{
		type = "bool-setting",
		name = "Nightfall-nightonly",
		setting_type = "runtime-global",
		default_value = false,
		order = "f"
	},
})