--basic interval for checks
timeinterval = 2700 --2700 is 45 seconds at 60 UPS
--how many chunks to process in a tick
processchunk = 5

--states
IDLE = 1
BASE_SEARCH = 2
ATTACKING = 3



script.on_init(function()
	global.bases = {}
	global.chunklist = {}
	global.groups = {}
	global.state = IDLE
	--prevents attacks from happening too often
	global.lastattack = 0
	
	-- this means we've been added to an existing save, instead of a new map
	-- So, we'll need to get a list of existing chunks instead of only tracking
	-- new ones.
	if game.tick > 0 then
		findchunks()
	end
	global.c_index=1
end)

script.on_event(defines.events.on_tick, function(event)
	if event.tick % timeinterval == 0 then
		if global.state == IDLE
			and event.tick >= global.lastattack + timeinterval
			and math.random() > 0.5
		then
			for index,surface in pairs(game.surfaces) do
				if surface.darkness >= 0.5 then
					--	Search for bases, then attack
					global.state = BASE_SEARCH
					--game.print("entering attack mode")
					break
				end
			end
		end
	end
	if event.tick % 120 == 0 and settings.global["Nightfall-nightonly"].value == true then
		for group_index, group in pairs(global.groups) do
			if group
				and group.valid == true
				and group.surface.darkness < 0.5
				and group.state == defines.group_state.moving
			then
				--game.print("ordering stop " .. tostring(event.tick))
				group.set_command({
					type = defines.command.stop,
					ticks_to_wait = 120*1,
					distraction = defines.distraction.by_enemy
				})
			elseif group == nil
				or group.valid == false
				or group.surface == nil
				or group.surface.valid == false
			then
				table.remove(global.groups, group_index)
			end
		end
	end
	if global.state == BASE_SEARCH then
		-- This is called every tick while in this state
		-- But only a small amount of work is done per call.
		-- State will change when it's finished.
		findbases()
	elseif global.state == ATTACKING then
		attack()
	end
	
end)

script.on_event(defines.events.on_chunk_generated, function(event)
	-- Manually rebuilding the chunk list with findchunks() is costly.
	-- So we'll track when new chunks are generated and just add them on.
	-- NOTE: The game's debug menu can show potentially hundreds of ungenerated chunks
	-- It's normal for this count to lag behind chunks in the debug menu.

	local chunk = {}
	local coords = event.area.left_top
	chunk.surface = event.surface.index
	chunk.x = coords.x+16
	chunk.y = coords.y+16
	table.insert(global.chunklist, chunk)

end)

script.on_event(defines.events.on_unit_group_created, function(event)
	if event.group.force.name == "enemy" and settings.global["Nightfall-nightonly"].value == true then
		table.insert(global.groups, event.group)
		--game.print("Group added " .. tostring(#global.groups))
	end
	
end)

function attack()
	local maxindex = #global.bases
	--local surface = game.surfaces[1]
	for i=global.c_index, global.c_index+processchunk, 1 do
		if i > maxindex then
			-- we're done here
			global.state = IDLE
			break
		end
		
		local surface = game.surfaces[global.bases[i].surface]
		
		if surface
			and surface.valid
			and surface.darkness >= 0.5
			and math.random() < surface.darkness
		then
			local base = global.bases[i]
			local group=surface.create_unit_group{position=base}
			for _, biter in ipairs(surface.find_enemy_units(base, 16)) do
				if biter.force.name == "enemy" then
					group.add_member(biter)
				end
			end
			if #group.members==0 then
				group.destroy()
			else
				--autonomous groups will attack polluted areas independently
				group.set_autonomous()
				-- REMEMBER TO TURN THIS OFF BEFORE RELEASE YOU FOOL
				--game.print("sending biters")
				--group.set_command{ type=defines.command.attack_area, destination=game.players[1].position, radius=200, distraction=defines.distraction.by_anything }
			end
		end
	end
	global.c_index = global.c_index + processchunk
	--Reset if we're moving to the next state.
	if global.state == IDLE then
		global.c_index = 1
		global.lastattack = game.tick
	end
end

function findbases()
	if global.c_index == 1 then
		global.bases = {}
	end
	local maxindex = #global.chunklist
	for i=global.c_index, global.c_index+processchunk, 1 do
		if i > maxindex then
			-- we're done with the search
			global.state = ATTACKING
			break
		end
		
		local chunkcoord = global.chunklist[i]
		local surface = game.surfaces[chunkcoord.surface]
		
		if surface == nil or surface.valid == false then
			table.remove(global.chunklist, i)
			global.c_index = global.c_index - 1
			maxindex = maxindex - 1
		elseif surface.get_pollution(chunkcoord) >= 1.0
			and (surface.count_entities_filtered{area={{chunkcoord.x-16, chunkcoord.y-16},{chunkcoord.x+16, chunkcoord.y+16}},
				type = "unit-spawner"}) > 0
		then					
			table.insert(global.bases,chunkcoord)
		end
	end
	global.c_index = global.c_index + processchunk
	--Reset if we're moving to the next state.
	if global.state == ATTACKING then
		global.c_index = 1
		shuffleTable(global.bases)
		--game.print("bases added: " .. tostring(#global.bases))
	end
end

function findchunks()
	global.chunklist = {}
	for index,surface in pairs(game.surfaces) do
		for coords in surface.get_chunks() do
			if surface.is_chunk_generated(coords) then
				local chunk = chunk_to_tiles(coords)
				chunk.surface = surface.index
				table.insert(global.chunklist, chunk)
			end
		end
	end
	--game.print("chunks added: " .. tostring(#global.chunklist))
end

function chunk_to_tiles(chunk) --transform chunk coords to coords of it's middle tile
	local tile={}
	tile.x=math.floor((chunk.x+0.5)*32)
	tile.y=math.floor((chunk.y+0.5)*32)
	return tile
end


function shuffleTable( t )
    assert( t, "shuffleTable() expected a table, got nil" )
    local iterations = #t
    local j
    
    for i = iterations, 2, -1 do
        j = math.random(i)
        t[i], t[j] = t[j], t[i]
    end
end