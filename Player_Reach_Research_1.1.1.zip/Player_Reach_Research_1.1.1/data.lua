data:extend({
  {
    type = "technology",
    name= "player-reach-upgrade-1",
    icon = "__Player_Reach_Research__/player-reach-research.png",
    icon_size = 64,
    effects =
    {
      {
        type = "character-reach-distance",
        modifier = 3
      },
	  {
        type = "character-build-distance",
        modifier = 2
      },
	  {
        type = "character-resource-reach-distance",
        modifier = 1
	  }
    },
    unit =
    {
      count_formula = "50*(2^(L-1))",
      ingredients =
      {
        {"automation-science-pack", 1},
      },
      time = 30
    },
    upgrade = true,
    max_level = "3",
    order = "c-k-f-a"
  },
  {
    type = "technology",
    name= "player-reach-upgrade-4",
    prerequisites = {"player-reach-upgrade-1"},
    icon = "__Player_Reach_Research__/player-reach-research.png",
    icon_size = 64,
    effects =
    {
      {
        type = "character-reach-distance",
        modifier = 3
      },
	  {
        type = "character-build-distance",
        modifier = 2
      },
	  {
        type = "character-resource-reach-distance",
        modifier = 1
      }
    },
    unit =
    {
      count_formula = "50*(2^(L-4))",
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
      },
      time = 30
    },
    upgrade = true,
    max_level = "7",
    order = "c-k-f-a"
  },
  {
    type = "technology",
    name= "player-reach-upgrade-8",
    prerequisites = {"player-reach-upgrade-4"},
    icon = "__Player_Reach_Research__/player-reach-research.png",
    icon_size = 64,
    effects =
    {
      {
        type = "character-reach-distance",
        modifier = 3
      },
	  {
        type = "character-build-distance",
        modifier = 2
      },
	  {
        type = "character-resource-reach-distance",
        modifier = 1
      }
    },
    unit =
    {
      count_formula = "50*(2^(L-8))",
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
      },
      time = 30
    },
    upgrade = true,
    max_level = "11",
    order = "c-k-f-a"
  },
  {
    type = "technology",
    name= "player-reach-upgrade-12",
    prerequisites = {"player-reach-upgrade-8"},
    icon = "__Player_Reach_Research__/player-reach-research.png",
    icon_size = 64,
    effects =
    {
      {
        type = "character-reach-distance",
        modifier = 3
      },
	  {
        type = "character-build-distance",
        modifier = 2
      },
	  {
        type = "character-resource-reach-distance",
        modifier = 1
      }
    },
    unit =
    {
      count_formula = "50*(2^(L-12))",
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
      },
      time = 30
    },
    upgrade = true,
    max_level = "15",
    order = "c-k-f-a"
  },
  {
    type = "technology",
    name= "player-reach-upgrade-16",
    prerequisites = {"player-reach-upgrade-12"},
    icon = "__Player_Reach_Research__/player-reach-research.png",
    icon_size = 64,
    effects =
    {
      {
        type = "character-reach-distance",
        modifier = 3
      },
	  {
        type = "character-build-distance",
        modifier = 2
      },
	  {
        type = "character-resource-reach-distance",
        modifier = 1
      }
    },
    unit =
    {
      count_formula = "50*(2^(L-16))",
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 30
    },
    upgrade = true,
    max_level = "19",
    order = "c-k-f-a"
  },
  {
    type = "technology",
    name= "player-reach-upgrade-20",
    prerequisites = {"player-reach-upgrade-16"},
    icon = "__Player_Reach_Research__/player-reach-research.png",
    icon_size = 64,
    effects =
    {
      {
        type = "character-reach-distance",
        modifier = 3
      },
	  {
        type = "character-build-distance",
        modifier = 2
      },
	  {
        type = "character-resource-reach-distance",
        modifier = 1
      }
    },
    unit =
    {
      count_formula = "50*(2^(L-20))",
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
        {"space-science-pack", 1}
      },
      time = 30
    },
    upgrade = true,
    max_level = "infinite",
    order = "c-k-f-a"
  },
})

data.raw["utility-sprites"].default.character_reach_modifier_icon = {
  filename = "__Player_Reach_Research__/player-reach-research.png",
  priority = "medium",
  width = 64,
  height = 64,
  flags = {"icon"}
}
