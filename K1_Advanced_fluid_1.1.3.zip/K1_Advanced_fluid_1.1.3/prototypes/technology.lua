data:extend(
{
	{
		type = "technology",
		name = "advanced-fluid-handling",
		icon = "__K1_Advanced_fluid__/graphics/technology/fs-200.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "fs-50"
			},
			{
				type = "unlock-recipe",
				recipe = "fs-200"
			},
		},
		prerequisites = {"fluid-handling"},
		order = "e-d-d",
		unit =
		{
			count = 100,
			ingredients = 
			{
				{"automation-science-pack", 1},
				{"logistic-science-pack", 1},
			},
			time = 15
		},
    },
}
)
