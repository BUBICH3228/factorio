data:extend(
{
	{
		type = "recipe",
		name = "fs-50",
		energy_required = 10,
		enabled = false,
		ingredients =
		{
			{"storage-tank", 2},
			{"steel-plate", 4}
		},
		result = "fs-50"
    },	
	{
		type = "recipe",
		name = "fs-200",
		energy_required = 30,
		enabled = false,
		ingredients =
		{
			{"storage-tank", 4},
			{"steel-plate", 8}
		},
		result = "fs-200"
    },
}
)
