data:extend(
{
	{
    type = "item",
    name = "fs-50",
    icon = "__K1_Advanced_fluid__/graphics/icons/fs-50.png",
	stack_size = 50,
    icon_size = 32,    
    subgroup = "storage",
    order = "b[fluid]-b[fs-50]",
    place_result = "fs-50"
    },

	{
    type = "item",
    name = "fs-200",
    icon = "__K1_Advanced_fluid__/graphics/icons/fs-200.png",
	stack_size = 20,
    icon_size = 32,    
    subgroup = "storage",
    order = "b[fluid]-c[fs-200]",
    place_result = "fs-200"
    },
}
)
