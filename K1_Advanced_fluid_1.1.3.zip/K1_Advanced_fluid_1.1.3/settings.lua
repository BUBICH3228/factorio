data:extend
({
{
type = "int-setting",
name = "small_tank_size",
order = "a",
setting_type = "startup",
default_value = 500,
minimum_value = 250,
maximum_value = 10000
},
{
type = "int-setting",
name = "large_tank_size",
order = "b",
setting_type = "startup",
default_value = 2000,
minimum_value = 250,
maximum_value = 10000
}
})