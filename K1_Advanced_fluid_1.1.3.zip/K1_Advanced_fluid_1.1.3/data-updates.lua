if mods["space-exploration"] then
data.raw["storage-tank"]["fs-50"].se_allow_in_space = true
data.raw["storage-tank"]["fs-200"].se_allow_in_space = true
end