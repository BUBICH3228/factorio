require("prototypes.item")
require("prototypes.technology")
require("prototypes.entities")
require("prototypes.recipe")