### Spidertron - huge grid (24x22)

The spidertron is just a minor addition or so they said ... boy, were they wrong.

Nearly unkillable, fast as hell and at least twice as deadly ...

``ALL HAIL MEGA-SPIDERTRON!``

![Huge-grid-spidertron]({{REPO}}/blob_plain/HEAD:/thumbnail.png)
![Huge-grid-spidertron]({{REPO}}/blob_plain/HEAD:/spidertron-on-ground-zero.png)
