-- make spidertron grid huge
data.raw["equipment-grid"]['spidertron-equipment-grid'].width = 24
data.raw["equipment-grid"]['spidertron-equipment-grid'].height = 22

data.raw["spider-vehicle"]['spidertron'].inventory_size = 160
data.raw["spider-vehicle"]['spidertron'].max_health = 30000
