data:extend(
{
	{
    type = "recipe-category",
    name = "rsc-stage1"
	},
	{
    type = "recipe-category",
    name = "rsc-stage2"
	},
	{
    type = "recipe-category",
    name = "rsc-stage3"
	},
	{
    type = "recipe-category",
    name = "rsc-stage4"
	},
	{
    type = "recipe-category",
    name = "rsc-stage5"
	},
	{
    type = "recipe-category",
    name = "rsc-stage6"
	},
	
}
)