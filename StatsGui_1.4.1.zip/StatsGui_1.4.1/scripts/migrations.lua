return {
  ["1.1.0"] = function()
    global.research_progress_strings = {}
  end,
}
