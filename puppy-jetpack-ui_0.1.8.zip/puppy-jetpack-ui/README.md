# Puppy's Jetpack UI

The purpose of this mod is to stick a small UI on the screen telling you how much fuel and thrust is left in your Jetpack.

## How to use it

The UI appears automatically when the Jetpack is enabled. The number is the remaining count of fuel in your inventory. The remaining fuel gauge updates once per second.

## Credits
This mod adds functionality to Earendel's Jetpack.