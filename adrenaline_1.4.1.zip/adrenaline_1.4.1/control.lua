local event_listener = require("__zk-lib__/event-listener/branch-1/stable-version")
local modules = {}
modules.adrenaline = require("adrenaline/control")

event_listener.add_libraries(modules)
