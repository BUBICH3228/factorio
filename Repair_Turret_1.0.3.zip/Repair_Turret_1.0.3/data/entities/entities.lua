local require = function(name) return require("data/entities/"..name) end
require("repair_turret/repair_turret")
