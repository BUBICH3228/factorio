if data.raw.technology["long-inserters-2"] then
    data.raw.technology["long-inserters-2"].prerequisites =
    {
      "long-inserters-1",
      "logistics-2",
    }
    data.raw.technology["long-inserters-2"].unit.ingredients =
    {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1}
    }
end
if data.raw.technology["more-inserters-2"] then
    data.raw.technology["more-inserters-2"].prerequisites =
    {
      "more-inserters-1",
      "logistics-2",
    }
    data.raw.technology["more-inserters-2"].unit.ingredients =
    {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1}
    }
end