data.raw["underground-belt"]["underground-belt"].max_distance = 9
data.raw["underground-belt"]["fast-underground-belt"].max_distance = 9