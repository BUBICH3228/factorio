data:extend({
  {
    type = 'custom-input',
    name = 'switchbutton-keybind',
    key_sequence = 'F',
  },
})
