data:extend{
  {
    type = 'recipe',
    name = 'switchbutton',
    enabled = 'false',
    ingredients =
    {
      {'constant-combinator', 1},
      {'electronic-circuit', 1},
    },
    result='switchbutton',
  },
}
