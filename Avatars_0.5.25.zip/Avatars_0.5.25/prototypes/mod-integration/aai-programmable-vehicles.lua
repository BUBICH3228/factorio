if mods["aai-programmable-vehicles"] and aai_vehicle_exclusions then
    table.insert(aai_vehicle_exclusions, "avatar-control-center")
    table.insert(aai_vehicle_exclusions, "avatar-remote-deployment-unit")
end
