data:extend({
{
	type = "custom-input",
	name = "avatars_disconnect",
	key_sequence = "F2"
}
})