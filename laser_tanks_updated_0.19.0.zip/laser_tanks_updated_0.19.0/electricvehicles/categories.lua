data:extend
{
  {
    type = "equipment-category",
    name = "electric-vehicles-equipment",
  },
  
  {
    type = "item-subgroup",
    name = "electric-vehicles-equipment",
    group = "combat",
    order = "g"
  },
}
