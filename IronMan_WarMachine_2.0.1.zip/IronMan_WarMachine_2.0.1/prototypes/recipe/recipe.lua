data:extend({
--See config.lua file for variable data

  {
    type = "recipe",
    name = "iron-armor",
    enabled = not IRON_ARMOR_REQUIRES_RESEARCH,
    energy_required = IRON_ARMOR_CONSTRUCT_TIME,
    ingredients = IRON_ARMOR_RECIPE,
    result = "iron-armor"
  },
  
  {
    type = "recipe",
	name = "arc-reactor",
	enabled = not ARC_REACTOR_REQUIRES_RESEARCH,
	energy_required = ARC_REACTOR_CONSTRUCT_TIME,
	ingredients = ARC_REACTOR_RECIPE,
	result = "arc-reactor"
  },
  
  {
    type = "recipe",
    name = "advanced-shields",
    enabled = not ADV_SHIELDS_REQUIRES_RESEARCH,
    energy_required = ADV_SHIELDS_CONSTRUCT_TIME,
    ingredients = ADV_SHIELDS_RECIPE,
    result = "advanced-shields"
  },
  
  {
    type = "recipe",
    name = "advanced-exoskeleton",
    enabled = not ADV_EXOSKELETON_REQUIRES_RESEARCH,
    energy_required = ADV_EXOSKELETON_CONSTRUCT_TIME,
    ingredients = ADV_EXOSKELETON_RECIPE,
    result = "advanced-exoskeleton"
  },
  
  {
    type = "recipe",
    name = "particle-beam",
    enabled = not PARTICLE_BEAM_REQUIRES_RESEARCH,
    energy_required = PARTICLE_BEAM_CONSTRUCT_TIME,
    ingredients = PARTICLE_BEAM_RECIPE,
    result = "particle-beam"
  },
  
  {
    type = "recipe",
    name = "minigun",
    enabled = not MINIGUN_REQUIRES_RESEARCH,
    energy_required = MINIGUN_CONSTRUCT_TIME,
    ingredients = MINIGUN_RECIPE,
    result = "minigun"
  },
  
  {
    type = "recipe",
    name = "mounted-launcher",
    enabled = not MOUNTED_LAUNCHER_REQUIRES_RESEARCH,
    energy_required = MOUNTED_LAUNCHER_CONSTRUCT_TIME,
    ingredients = MOUNTED_LAUNCHER_RECIPE,
    result = "mounted-launcher"
  }

})