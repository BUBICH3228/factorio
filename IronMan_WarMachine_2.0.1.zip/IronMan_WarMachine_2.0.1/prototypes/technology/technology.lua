data:extend({
--See config.lua file for variable data

  {
  -- IRON MAN ARMOR RESEARCH
    type = "technology",
    name = "stark-industries",
    icon = "__IronMan_WarMachine__/graphics/technology/stark-tech.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "iron-armor"
      },
			{
			  type = "unlock-recipe",
				recipe = "alien-biomatter"
			}
    },
    prerequisites = {"power-armor-mk2", "military-4"},
    unit =
    {
      count = IRON_ARMOR_RESEARCH_COUNT,
      ingredients = IRON_ARMOR_RESEARCH_COST,
      time = IRON_ARMOR_RESEARCH_TIME
    },
    order = "g-c-c"
  },
  
  {
  -- ARC REACTOR RESEARCH
    type = "technology",
    name = "arc-reactor",
    icon = "__IronMan_WarMachine__/graphics/technology/arc-reactor-tech.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "arc-reactor"
      }
    },
    prerequisites = {"fusion-reactor-equipment", "stark-industries"},
    unit =
    {
      count = ARC_REACTOR_RESEARCH_COUNT,
      ingredients = ARC_REACTOR_RESEARCH_COST,
      time = ARC_REACTOR_RESEARCH_TIME
    },
    order = "g-c-c-a"
  },
  
  {
   -- ADVANCED SHIELDS RESEARCH
    type = "technology",
    name = "advanced-shields",
    icon = "__IronMan_WarMachine__/graphics/technology/advanced-shields-tech.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-shields"
      }
    },
    prerequisites = {"energy-shield-mk2-equipment", "stark-industries"},
    unit =
    {
      count = ADV_SHIELDS_RESEARCH_COUNT,
      ingredients = ADV_SHIELDS_RESEARCH_COST,
      time = ADV_SHIELDS_RESEARCH_TIME
    },
    order = "g-c-c-b"
  },
  
  {
  -- ADVANCED EXOSKELETON RESEARCH
    type = "technology",
    name = "advanced-exoskeleton",
    icon = "__IronMan_WarMachine__/graphics/technology/advanced-exoskeleton-tech.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-exoskeleton"
      }
    },
    prerequisites = {"exoskeleton-equipment", "stark-industries"},
    unit =
    {
      count = ADV_EXOSKELETON_RESEARCH_COUNT,
      ingredients = ADV_EXOSKELETON_RESEARCH_COST,
      time = ADV_EXOSKELETON_RESEARCH_TIME
    },
    order = "g-c-c-c"
  },
  
  {
  -- PARTICLE BEAM RESEARCH
    type = "technology",
    name = "particle-beam",
    icon = "__IronMan_WarMachine__/graphics/technology/particle-beam-tech.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "particle-beam"
      }
    },
    prerequisites = {"personal-laser-defense-equipment", "stark-industries"},
    unit =
    {
      count = PARTICLE_BEAM_RESEARCH_COUNT,
      ingredients = PARTICLE_BEAM_RESEARCH_COST,
      time = PARTICLE_BEAM_RESEARCH_TIME
    },
    order = "g-c-c-d"
  },
  
  {
  -- MINIGUN RESEARCH
    type = "technology",
    name = "minigun",
    icon = "__IronMan_WarMachine__/graphics/technology/minigun-tech.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "minigun"
      }
    },
    prerequisites = {"particle-beam"},
    unit =
    {
      count = MINIGUN_RESEARCH_COUNT,
      ingredients = MINIGUN_RESEARCH_COST,
      time = MINIGUN_RESEARCH_TIME
    },
    order = "g-c-c-d-a"
  },
  
  {
   -- MOUNTED ROCKET LAUNCHER RESEARCH
    type = "technology",
    name = "mounted-launcher",
    icon = "__IronMan_WarMachine__/graphics/technology/mounted-launcher-tech.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "mounted-launcher"
      }
    },
    prerequisites = {"minigun"},
    unit =
    {
      count = MOUNTED_LAUNCHER_RESEARCH_COUNT,
      ingredients = MOUNTED_LAUNCHER_RESEARCH_COST,
      time = MOUNTED_LAUNCHER_RESEARCH_TIME
    },
    order = "g-c-c-d-b"
  },
  
})