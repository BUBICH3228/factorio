data:extend({
--See config.lua file for variable data

  {
    type = "equipment-grid",
    name = "iron-grid",
    width = IRON_ARMOR_GRID_WIDTH,
    height = IRON_ARMOR_GRID_HEIGHT,
    equipment_categories = {"armor"}
  },
  
  {
    type = "item",
    name = "arc-reactor",
    icon = "__IronMan_WarMachine__/graphics/icons/arc-reactor-icon.png",
		icon_size = 32,
    placed_as_equipment_result = "arc-reactor",
    subgroup = "equipment",
    order = "a[energy-source]-c[arc-reactor]",
    stack_size = ARC_REACTOR_STACK
  },
  
  {
    type = "item",
    name = "advanced-shields",
    icon = "__IronMan_WarMachine__/graphics/icons/advanced-shields-icon.png",
		icon_size = 32,
    placed_as_equipment_result = "advanced-shields",

    subgroup = "equipment",
    order = "b[shield]-c[advanced-shields]",
    stack_size = ADV_SHIELDS_STACK
  },

  {
    type = "item",
    name = "advanced-exoskeleton",
    icon = "__IronMan_WarMachine__/graphics/icons/advanced-exoskeleton-icon.png",
		icon_size = 32,
    placed_as_equipment_result = "advanced-exoskeleton",

    subgroup = "equipment",
    order = "e[exoskeleton]-b[advanced-exoskeleton]",
    stack_size = ADV_EXOSKELETON_STACK
  },
  
  {
    type = "item",
    name = "particle-beam",
    icon = "__IronMan_WarMachine__/graphics/icons/particle-beam-icon.png",
		icon_size = 32,
    placed_as_equipment_result = "particle-beam",

    subgroup = "equipment",
    order = "d[active-defense]-c[particle-beam]",
    stack_size = PARTICLE_BEAM_STACK
  },
  
  {
    type = "item",
    name = "minigun",
    icon = "__IronMan_WarMachine__/graphics/icons/minigun-icon.png",
		icon_size = 32,
    placed_as_equipment_result = "minigun",

    subgroup = "equipment",
    order = "d[active-defense]-d[minigun]",
    stack_size = MINIGUN_STACK
  },
  
  {
    type = "item",
    name = "mounted-launcher",
    icon = "__IronMan_WarMachine__/graphics/icons/mounted-launcher-icon.png",
		icon_size = 32,
    placed_as_equipment_result = "mounted-launcher",

    subgroup = "equipment",
    order = "d[active-defense]-e[mounted-launcher]",
    stack_size = MOUNTED_LAUNCHER_STACK
  }

})