data:extend({
	{
    type = "item",
    name = "alien-biomatter",
    icon = "__IronMan_WarMachine__/graphics/icons/alien-biomatter.png",
		icon_size = 32,
    subgroup = "raw-material",
    order = "g[alien-biomatter]",
    stack_size = 100,
    default_request_amount = 10
  },
	
	{
	type = "recipe",
	name = "alien-biomatter",
	enabled = false,
	ingredients = {
			{"automation-science-pack", 5},
			{"production-science-pack", 5}
	},
	result = "alien-biomatter",
	result_count = 1,
	requester_paste_multiplier = 8,
	energy_required = 1.0
	}
})
