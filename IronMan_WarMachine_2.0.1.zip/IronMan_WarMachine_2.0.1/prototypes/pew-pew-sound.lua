
function make_pew_sounds(volume)
  return
  {
    {
	  filename = "__IronMan_WarMachine__/sound/pew.ogg",
	  volume = 0.5
	},
	{
	  filename = "__IronMan_WarMachine__/sound/pang.ogg",
	  volume = 0.5
	},
	{
	  filename = "__IronMan_WarMachine__/sound/pow.ogg",
	  volume = 0.5
	}
  }
end