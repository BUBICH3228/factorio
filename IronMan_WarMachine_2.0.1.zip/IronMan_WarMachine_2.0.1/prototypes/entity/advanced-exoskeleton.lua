data:extend({
--See config.lua file for variable data
  
  {
    type = "movement-bonus-equipment",
    name = "advanced-exoskeleton",
    sprite =
    {
      filename = "__IronMan_WarMachine__/graphics/equipment/advanced-exoskeleton-equipment.png",
      width = 64,
      height = 128,
      priority = "medium"
    },
    shape =
    {
      width = ADV_EXOSKELETON_GRID_WIDTH,
      height = ADV_EXOSKELETON_GRID_HEIGHT,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input"
    },
    energy_consumption = ADV_EXOSKELETON_ENERGY_COST,
    movement_bonus = ADV_EXOSKELETON_MOVEMENT_BONUS,
    categories = {"armor"}
  }
  
})