data:extend({
--See config.lua file for variable data
  
  {
    type = "energy-shield-equipment",
    name = "advanced-shields",
    sprite =
    {
      filename = "__IronMan_WarMachine__/graphics/equipment/advanced-shields-equipment.png",
      width = 64,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = ADV_SHIELDS_GRID_WIDTH,
      height = ADV_SHIELDS_GRID_HEIGHT,
      type = "full"
    },
    max_shield_value = ADV_SHIELDS_MAX_SHIELD_VALUE,
    energy_source =
    {
      type = "electric",
      buffer_capacity = ADV_SHIELDS_BUFFER_CAP,
      input_flow_limit = ADV_SHIELDS_INPUT_FLOW,
      usage_priority = "primary-input"
    },
    energy_per_shield = ADV_SHIELDS_ENERGY_PER_SHIELD,
    categories = {"armor"}
  }

})