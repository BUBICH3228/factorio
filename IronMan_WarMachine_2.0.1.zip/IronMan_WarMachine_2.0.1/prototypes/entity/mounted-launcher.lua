data:extend({
--See config.lua file for variable data

  {
    type = "active-defense-equipment",
    name = "mounted-launcher",
    sprite =
    {
      filename = "__IronMan_WarMachine__/graphics/equipment/mounted-launcher-equipment.png",
      width = 128,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = MOUNTED_LAUNCHER_GRID_WIDTH,
      height = MOUNTED_LAUNCHER_GRID_HEIGHT,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      buffer_capacity = MOUNTED_LAUNCHER_BUFFER_CAP
    },
	
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "rocket",
      cooldown = 60 / MOUNTED_LAUNCHER_SHOTS_PER_SECOND,
	  movement_slow_down_factor = 0.8,
      damage_modifier = MOUNTED_LAUNCHER_DAMAGE_MODIFIER,
      projectile_center = {-0.17, 0},
      projectile_creation_distance = 0.6,
      range = MOUNTED_LAUNCHER_RANGE,
      sound =
      {
        {
          filename = "__base__/sound/fight/rocket-launcher.ogg",
          volume = 0.7
        }
      },
	  ammo_type =
      {
        type = "projectile",
        category = "rocket",
        energy_consumption = MOUNTED_LAUNCHER_ENERGY_CONSUMPTION,
        projectile = "explosive-rocket",
        speed = 1,
        action =
        {
          {
            type = "direct",
            action_delivery =
            {
              {
                type = "projectile",
                projectile = "explosive-rocket",
                starting_speed = 0.28
              }
            }
          }
        }
      }
    },
	
    automatic = true,
    categories = {"armor"}
  }
  
})