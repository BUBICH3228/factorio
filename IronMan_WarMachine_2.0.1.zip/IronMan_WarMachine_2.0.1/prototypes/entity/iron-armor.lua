data:extend({
--See config.lua file for variable data
  
  {
    type = "armor",
    name = "iron-armor",
    icon = "__IronMan_WarMachine__/graphics/icons/iron-armor-icon.png",
		icon_size = 32,
    resistances =
    {
      {
        type = "physical",
        decrease = IRON_ARMOR_PHYSICAL_D,
        percent = IRON_ARMOR_PHYSICAL_P
      },
      {
        type = "acid",
        decrease = IRON_ARMOR_ACID_D,
        percent = IRON_ARMOR_ACID_P
      },
      {
        type = "explosion",
        decrease = IRON_ARMOR_EXPLOSION_D,
        percent = IRON_ARMOR_EXPLOSION_P
      },
      {
        type = "fire",
        decrease = IRON_ARMOR_FIRE_D,
        percent = IRON_ARMOR_FIRE_P
      }
    },
    durability = IRON_ARMOR_DURABILITY,
    subgroup = "armor",
    order = "f[iron-armor]",
    stack_size = IRON_ARMOR_STACK,
    equipment_grid = "iron-grid",
    inventory_size_bonus = IRON_ARMOR_INVENTORY_BONUS
  }
  
})  