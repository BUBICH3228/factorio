data:extend({
--See config.lua file for variable data

  {
    type = "generator-equipment",
	name = "arc-reactor",
	sprite =
	{
	  filename = "__IronMan_WarMachine__/graphics/equipment/arc-reactor-equipment.png",
	  width = 64,
	  height = 64,
	  priority = "medium"
	},
	shape =
	{
      width = ARC_REACTOR_GRID_WIDTH,
	  height = ARC_REACTOR_GRID_HEIGHT,
	  type = "full"
	},
	energy_source =
	{
	  type = "electric",
	  usage_priority = "primary-output"
	},
	power = ARC_REACTOR_POWER,
	categories = {"armor"}
  }
  
})
