data:extend({
--See config.lua file for variable data

  {
    type = "active-defense-equipment",
    name = "minigun",
    sprite =
    {
      filename = "__IronMan_WarMachine__/graphics/equipment/minigun-equipment.png",
      width = 64,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = MINIGUN_GRID_WIDTH,
      height = MINIGUN_GRID_HEIGHT,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      buffer_capacity = MINIGUN_BUFFER_CAP
    },
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "electric",
      cooldown = 60 / MINIGUN_SHOTS_PER_SECOND,
      damage_modifier = MINIGUN_DAMAGE_MODIFIER,
      projectile_center = {0, 0},
      projectile_creation_distance = 0.6,
      range = MINIGUN_RANGE,
      sound = make_laser_sounds(),
      ammo_type =
      {
        type = "projectile",
        category = "electric",
        energy_consumption = MINIGUN_ENERGY_CONSUMPTION,
        projectile = "laser",
        speed = 1,
        action =
        {
          {
            type = "direct",
            action_delivery =
            {
              {
                type = "projectile",
                projectile = "laser",
                starting_speed = 0.28
              }
            }
          }
        }
      }
    },
    automatic = true,
    categories = {"armor"}
  }

})