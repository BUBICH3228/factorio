data:extend({
--See config.lua file for variable data

  {
    type = "active-defense-equipment",
    name = "particle-beam",
    sprite =
    {
      filename = "__IronMan_WarMachine__/graphics/equipment/particle-beam-equipment.png",
      width = 96,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = PARTICLE_BEAM_GRID_WIDTH,
      height = PARTICLE_BEAM_GRID_HEIGHT,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      buffer_capacity = PARTICLE_BEAM_BUFFER_CAP
    },
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "electric",
      cooldown = 60 / PARTICLE_BEAM_SHOTS_PER_SECOND,
      damage_modifier = PARTICLE_BEAM_DAMAGE_MODIFIER,
      projectile_center = {0, 0},
      projectile_creation_distance = 0.6,
      range = PARTICLE_BEAM_RANGE,
      sound = make_pew_sounds(),
      ammo_type =
      {
        type = "projectile",
        category = "electric",
        energy_consumption = PARTICLE_BEAM_ENERGY_CONSUMPTION,
        projectile = "particle",
        speed = 1,
        action =
        {
          {
            type = "direct",
            action_delivery =
            {
              {
                type = "projectile",
                projectile = "particle",
                starting_speed = 0.28
              }
            }
          }
        }
      }
    },
    automatic = true,
    categories = {"armor"}
  }
    
})