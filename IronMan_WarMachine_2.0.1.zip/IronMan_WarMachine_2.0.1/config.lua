
--[[ IRON MAN CONFIGURATION FILE --]]

--[[

  This mod is HIGHLY configurable
  
  The default settings make for a virtually invincible character
  Comments above each line annotate vanilla equivalent items for comparison
  Change as desired for appropriate challenge level
 
--]]


--[[ ******** IRON MAN ARMOR STATS ******** --]]
 
--Mk2 Armor: 20000 Durability
IRON_ARMOR_DURABILITY = 90000

--Mk2 Armor: Grid Size for equipment modules 10 width x 10 height
IRON_ARMOR_GRID_WIDTH = 25
IRON_ARMOR_GRID_HEIGHT = 25

--Mk2 Armor: Inventory Size Increase 30 slots
IRON_ARMOR_INVENTORY_BONUS = 90

--Mk2 Armor: Physical Defense 10/40 (10 = Decrease, 40 = Percent)
IRON_ARMOR_PHYSICAL_D = 60
IRON_ARMOR_PHYSICAL_P = 90

--Mk2 Armor: Acid Defense 10/40 (10 = Decrease, 40 = Percent)
IRON_ARMOR_ACID_D = 60
IRON_ARMOR_ACID_P = 90

--Mk2 Armor: Explosion Defense 20/50 (20 = Decrease, 50 = Percent)
IRON_ARMOR_EXPLOSION_D = 90
IRON_ARMOR_EXPLOSION_P = 90

--Mk2 Armor: Fire Defense 0/80 (0 = Decrease, 80 = Percent)
IRON_ARMOR_FIRE_D = 0
IRON_ARMOR_FIRE_P = 100

--Mk2 Armor: Recipe
--		5x efficiency module 3
--		5x speed module 3
--		40x processing unit
--		40x steel plate
--		50x alien artifact
IRON_ARMOR_RECIPE = {
 {"power-armor-mk2", 1},
 {"low-density-structure", 40},
 {"electric-engine-unit", 40},
 {"processing-unit", 100},
 {"alien-biomatter", 500}
}

--Mk2 Armor: Stack Size 1
IRON_ARMOR_STACK = 1

--Mk2 Armor: 40 seconds to construct
IRON_ARMOR_CONSTRUCT_TIME = 80

--Mk2 Armor: Research required (setting to false means it will be available immediately)
IRON_ARMOR_REQUIRES_RESEARCH = true

--Mk2 Armor: Research count 150
--Mk2 Armor: Cost: Pack 1(1), Pack 2(1), Pack 3(1), Pack Alien(3)
--Works as: 150x1, 150x1, 150x1, 150x3 for total cost by pack
--Mk2 Armor: Research time cost: 30 (seconds)
IRON_ARMOR_RESEARCH_COUNT = 500
IRON_ARMOR_RESEARCH_TIME = 30
IRON_ARMOR_RESEARCH_COST = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"military-science-pack", 1},
}


--[[ ******** ARC REACTOR STATS ******** --]]

--Portable Fusion Reactor: Takes up 4x4 Grid Size
ARC_REACTOR_GRID_WIDTH = 2
ARC_REACTOR_GRID_HEIGHT = 2

--Portable Fusion Reactor: 750kW Power Supply (reference: 1000kW = 1MW)
ARC_REACTOR_POWER = "5GW"

--Portable Fusion Reactor: Recipe
--		100x processing unit
--		30x alien artifact
ARC_REACTOR_RECIPE = {
  {"fusion-reactor-equipment", 1},
  {"processing-unit", 100},
  {"alien-biomatter", 100}
}

--Portable Fusion Reactor: Stack Size 20
ARC_REACTOR_STACK = 20

--Portable Fusion Reactor: 10 seconds construct time
ARC_REACTOR_CONSTRUCT_TIME = 20

--Portable Fusion Reactor: Research required (setting to false means it will be available immediately)
ARC_REACTOR_REQUIRES_RESEARCH = true

--Portable Fusion Reactor: Research count 200
--Portable Fusion Reactor: Cost: Pack 1(1), Pack 2(1), Pack 3(1)
--Portable Fusion Reactor: Research time cost: 30 (seconds)
ARC_REACTOR_RESEARCH_COUNT = 300
ARC_REACTOR_RESEARCH_TIME = 30
ARC_REACTOR_RESEARCH_COST = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"military-science-pack", 1},
}


--[[ ******** ADVANCED SHIELDS STATS ******** --]]

--Energy Shield Equipment Mk2: Takes up 2 width x 2 height Grid Size
ADV_SHIELDS_GRID_WIDTH = 2
ADV_SHIELDS_GRID_HEIGHT = 2

--Energy Shield Equipment Mk2: Max Shield Value 150
ADV_SHIELDS_MAX_SHIELD_VALUE = 2500

--Energy Shield Equipment Mk2: Buffer Capacity 180kJ
ADV_SHIELDS_BUFFER_CAP = "750kW"

--Energy Shield Equipment Mk2: Input Flow Limit 360kW
ADV_SHIELDS_INPUT_FLOW = "1MW"

--Energy Shield Equipment Mk2: Energy per Shield 30kJ
ADV_SHIELDS_ENERGY_PER_SHIELD = "100kW"

--Energy Shield Equipment Mk2: Recipe
--		10x energy shield equipment  
--		10x processing unit
ADV_SHIELDS_RECIPE = {
  {"energy-shield-mk2-equipment", 10},
  {"processing-unit", 15}
}

--Energy Shield Equipment Mk2: Stack Size 50
ADV_SHIELDS_STACK = 50

--Energy Shield Equipment Mk2: 10 seconds construct time
ADV_SHIELDS_CONSTRUCT_TIME = 15

--Energy Shield Equipment Mk2: Research required (setting to false means it will be available immediately)
ADV_SHIELDS_REQUIRES_RESEARCH = true

--Energy Shield Equipment Mk2: Research count 200
--Energy Shield Equipment Mk2: Cost: Pack 1(1), Pack 2(1), Pack 3(1)
--Energy Shield Equipment Mk2: Research time cost: 30 (seconds)
ADV_SHIELDS_RESEARCH_COUNT = 300
ADV_SHIELDS_RESEARCH_TIME = 35
ADV_SHIELDS_RESEARCH_COST = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"military-science-pack", 1},
}


--[[ ******** ADVANCED EXOSKELETON STATS ******** --]]

--Exoskeleton: Takes up 2x4 Grid Size
ADV_EXOSKELETON_GRID_WIDTH = 2
ADV_EXOSKELETON_GRID_HEIGHT = 4

--Exoskeleton: Energy Consumption 200kW
ADV_EXOSKELETON_ENERGY_COST = "250kW"

--Exoskeleton: Movement Bonus 0.3
ADV_EXOSKELETON_MOVEMENT_BONUS = 0.85

--Exoskeleton: Recipe
--		10x processing unit
--		30x electric engine unit
--		20x steel plate
ADV_EXOSKELETON_RECIPE = {
  {"exoskeleton-equipment", 1},
  {"processing-unit", 20},
  {"alien-biomatter", 30}
}

--Exoskeleton: Stack Size 10
ADV_EXOSKELETON_STACK = 10

--Exoskeleton: 10 seconds construct time
ADV_EXOSKELETON_CONSTRUCT_TIME = 20

--Exoskeleton: Research required (setting to false means it will be available immediately)
ADV_EXOSKELETON_REQUIRES_RESEARCH = true

--Exoskeleton: Research count 50
--Exoskeleton: Cost: Pack 1(1), Pack 2(1), Pack 3(1)
--Exoskeleton: Research time cost: 30 (seconds)
ADV_EXOSKELETON_RESEARCH_COUNT = 300
ADV_EXOSKELETON_RESEARCH_TIME = 30
ADV_EXOSKELETON_RESEARCH_COST = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"military-science-pack", 1},
}


--[[ ******** PARTICLE BEAM STATS ******** --]]

--Personal Laser Defense: Takes up 2 width x 3 height Grid Size
PARTICLE_BEAM_GRID_WIDTH = 3
PARTICLE_BEAM_GRID_HEIGHT = 2

--Personal Laser Defense: Buffer Capacity 110kJ
PARTICLE_BEAM_BUFFER_CAP = "110kJ"

--Personal Laser Defense: Shots per second 3 (every second, 3 shots are fired)
PARTICLE_BEAM_SHOTS_PER_SECOND = 12

--Personal Laser Defense: Damage Modifier 1 x (laser damage 5)
--Note: PARTICLE_BEAM_DAMAGE_MODIFIER x (laser damage 8)
PARTICLE_BEAM_DAMAGE_MODIFIER = 3

--Personal Laser Defense: Laser Range 15
PARTICLE_BEAM_RANGE = 35

--Personal Laser Defense: Energy Consumption per shot 100kJ
PARTICLE_BEAM_ENERGY_CONSUMPTION = "50kJ"

--Personal Laser Defense: Recipe
--		1x processing unit 
--		5x steel plate
--		5x laser turret
PARTICLE_BEAM_RECIPE = {
  {"personal-laser-defense-equipment", 1},
  {"processing-unit", 20},
  {"alien-biomatter", 50}
}

--Personal Laser Defense: Stack Size 20
PARTICLE_BEAM_STACK = 20

----Personal Laser Defense: 10 seconds construct time
PARTICLE_BEAM_CONSTRUCT_TIME = 20

----Personal Laser Defense: Research required (setting to false means it will be available immediately)
PARTICLE_BEAM_REQUIRES_RESEARCH = true

--Personal Laser Defense: Research count 100
--Personal Laser Defense: Cost: Pack 1(1), Pack 2(1), Pack 3(1)
--Personal Laser Defense: Research time cost: 30 (seconds)
PARTICLE_BEAM_RESEARCH_COUNT = 300
PARTICLE_BEAM_RESEARCH_TIME = 30
PARTICLE_BEAM_RESEARCH_COST = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"military-science-pack", 1},
}


--[[ ******** MINIGUN STATS ******** --]]

--Personal Laser Defense: Takes up 2 width x 3 height Grid Size
MINIGUN_GRID_WIDTH = 2
MINIGUN_GRID_HEIGHT = 2

--Personal Laser Defense: Buffer Capacity 110kJ
MINIGUN_BUFFER_CAP = "90kJ"

--Personal Laser Defense: Shots per second 3 (every second, 3 shots are fired)
MINIGUN_SHOTS_PER_SECOND = 35

--Personal Laser Defense: Damage Modifier 1 x (laser damage 5)
MINIGUN_DAMAGE_MODIFIER = 1.6

--Personal Laser Defense: Laser Range 15
MINIGUN_RANGE = 15

--Personal Laser Defense: Energy Consumption per shot 100kJ
MINIGUN_ENERGY_CONSUMPTION = "15kJ"

--Personal Laser Defense: Recipe
--		1x processing unit 
--		5x steel plate
--		5x laser turret
MINIGUN_RECIPE = {
  {"personal-laser-defense-equipment", 1},
  {"processing-unit", 20},
  {"alien-biomatter", 50}
}

--Personal Laser Defense: Stack Size 20
MINIGUN_STACK = 20

----Personal Laser Defense: 10 seconds construct time
MINIGUN_CONSTRUCT_TIME = 20

----Personal Laser Defense: Research required (setting to false means it will be available immediately)
MINIGUN_REQUIRES_RESEARCH = true

--Personal Laser Defense: Research count 100
--Personal Laser Defense: Cost: Pack 1(1), Pack 2(1), Pack 3(1)
--Personal Laser Defense: Research time cost: 30 (seconds)
MINIGUN_RESEARCH_COUNT = 400
MINIGUN_RESEARCH_TIME = 30
MINIGUN_RESEARCH_COST = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"military-science-pack", 1},
}


--[[ ******** MOUNTED LAUNCHER STATS ******** --]]

--Personal Laser Defense: Takes up 2 width x 3 height Grid Size
MOUNTED_LAUNCHER_GRID_WIDTH = 4
MOUNTED_LAUNCHER_GRID_HEIGHT = 2

--Personal Laser Defense: Buffer Capacity 110kJ
MOUNTED_LAUNCHER_BUFFER_CAP = "110kJ"

--Personal Laser Defense: Shots per second 3 (every second, 3 shots are fired)
MOUNTED_LAUNCHER_SHOTS_PER_SECOND = 1

--Personal Laser Defense: Damage Modifier 1 x (laser damage 5)
MOUNTED_LAUNCHER_DAMAGE_MODIFIER = 1.0

--Personal Laser Defense: Laser Range 15
MOUNTED_LAUNCHER_RANGE = 30

--Personal Laser Defense: Energy Consumption per shot 100kJ
MOUNTED_LAUNCHER_ENERGY_CONSUMPTION = "30kJ"

--Personal Laser Defense: Recipe
--		1x processing unit 
--		5x steel plate
--		5x laser turret
MOUNTED_LAUNCHER_RECIPE = {
  {"personal-laser-defense-equipment", 1},
  {"rocket-launcher", 1},
  {"processing-unit", 20},
  {"explosives", 100},
  {"alien-biomatter", 50}
}

--Personal Laser Defense: Stack Size 20
MOUNTED_LAUNCHER_STACK = 20

----Personal Laser Defense: 10 seconds construct time
MOUNTED_LAUNCHER_CONSTRUCT_TIME = 30

----Personal Laser Defense: Research required (setting to false means it will be available immediately)
MOUNTED_LAUNCHER_REQUIRES_RESEARCH = true

--Personal Laser Defense: Research count 100
--Personal Laser Defense: Cost: Pack 1(1), Pack 2(1), Pack 3(1)
--Personal Laser Defense: Research time cost: 30 (seconds)
MOUNTED_LAUNCHER_RESEARCH_COUNT = 500
MOUNTED_LAUNCHER_RESEARCH_TIME = 35
MOUNTED_LAUNCHER_RESEARCH_COST = {
  {"automation-science-pack", 1},
  {"logistic-science-pack", 1},
  {"military-science-pack", 1},
}