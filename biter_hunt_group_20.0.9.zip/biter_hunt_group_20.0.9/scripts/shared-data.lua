local SharedData = {}

SharedData.biterHuntGroupState = {scheduled = "scheduled", warning = "warning", groundMovement = "groundMovement", preBitersSpawnEffect = "preBitersSpawnEffect", spawnBiters = "spawnBiters", bitersActive = "bitersActive"}

return SharedData
