local Constants = {}

Constants.ModName = "biter_hunt_group"
Constants.AssetModName = "__" .. Constants.ModName .. "__"
Constants.LogFileName = Constants.ModName .. "_logOutput.txt"

return Constants
